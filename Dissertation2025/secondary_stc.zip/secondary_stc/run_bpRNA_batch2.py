#!/usr/bin/env python3
import os
import sys
import argparse
import subprocess
from pathlib import Path
import csv

def run_one(bprna_pl: Path, bpseq_file: Path, force: bool) -> tuple[bool, str]:
    out_st = bpseq_file.with_suffix(".st") # bpRNA structure file
    out_ss = bpseq_file.with_suffix(".ss") # secondary-structure file

    if not force and out_st.exists() and out_ss.exists(): # skip if outputs already exist 
        return True, f"SKIP (already exists): {bpseq_file}"

    try:
        proc = subprocess.run(
            ["perl", str(bprna_pl), str(bpseq_file)],
            cwd=str(bpseq_file.parent),  
            stdout=subprocess.PIPE,

            stderr=subprocess.PIPE,
            text=True # decode to str
        )
        if proc.returncode != 0: # non-zero indicates failure
            return False, f"ERROR ({bpseq_file}): {proc.stderr.strip() or proc.stdout.strip()}"
        return True, f"DONE: {bpseq_file}"
    except FileNotFoundError as e:
        return False, f"Perl/bpRNA not found: {e}"
    except Exception as e:
        return False, f"Unexpected error for {bpseq_file}: {e}" 

def main(): # run bpRNA over -> .bpseq files -> write manifest
    p = argparse.ArgumentParser(description="Run bpRNA on all .bpseq files under a root folder.")
    p.add_argument("--bpseq-root", required=True)
    p.add_argument("--bprna-path", required=True) # path to bpRNA.pl
    p.add_argument("--force", action="store_true")
    p.add_argument("--manifest", default="bprna_manifest.csv") # out
    args = p.parse_args()

    bpseq_root = Path(args.bpseq_root).expanduser().resolve()
    bprna_pl = Path(args.bprna_path).expanduser().resolve()
    manifest_path = Path(args.manifest).expanduser().resolve()
    # check paths
    if not bpseq_root.exists() or not bprna_pl.exists():
        print("Check paths to bpseq root and bpRNA.pl", file=sys.stderr)
        sys.exit(1)

    bpseq_files = list(bpseq_root.rglob("*.bpseq")) # all .bpseq files 
    print(f"Found {len(bpseq_files)} .bpseq files.")

    rows, ok, fail = [], 0, 0
    for f in bpseq_files:
        success, msg = run_one(bprna_pl, f, args.force) # run per-file
        print(msg) 
        rows.append({
            "bpseq_path": str(f),
            "st_path": str(f.with_suffix('.st')),
            "ss_path": str(f.with_suffix('.ss')),
            "status": "ok" if success else "error",
            "message": msg
        })
        if success: ok += 1
        else: fail += 1

    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    with open(manifest_path, "w", newline="") as csvfile:
        w = csv.DictWriter(csvfile, fieldnames=rows[0].keys())

        w.writeheader()
        w.writerows(rows)

    print(f"\nCompleted. OK: {ok}, FAIL: {fail}")
    
    print(f"Manifest saved to: {manifest_path}")

if __name__ == "__main__":
    main()
