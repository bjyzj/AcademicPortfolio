
#!/usr/bin/env python3
import re, sys, csv
from pathlib import Path

# patterns for parsing bpRNA .st files
pat_name = re.compile(r'^#Name:\s+(.*)')
pat_len  = re.compile(r'^#?\s*Length\s*:\s*(\d+)', re.IGNORECASE)  # more flexible pattern
pat_S    = re.compile(r'^S\d+\s') # Stem line
pat_H    = re.compile(r'^H\d+\s') # Hairpin loop
pat_B    = re.compile(r'^B\d+\s') # Bulge
pat_I    = re.compile(r'^I\d+(?:\.\d+)?\s') # Internal loop
pat_M    = re.compile(r'^M\d+(?:\.\d+)?\s') # Multiloop
pat_E    = re.compile(r'^E\d+\s') # Exterior region
pat_PK   = re.compile(r'^PK\d+\s+(\d+)bp') # Pseudoknot line
pat_seg  = re.compile(r'^segment\d+\s+(\d+)bp') # Segment summary -- capture bp count

def count_shapes(st_path: Path):
    name = st_path.stem
    length = None
    cS = cH = cI = cM = cB = cE = cSEG = cPK = 0
    pk_bp_total = 0

    with st_path.open() as f:
        for raw in f:
            ln = raw.strip()
            if not ln:
                continue
            if m := pat_name.match(ln):
                name = m.group(1)
                continue
            if length is None:
                m = pat_len.match(ln)
                if m:
                    length = int(m.group(1))
                    continue
            if pat_S.match(ln): cS += 1; continue
            if pat_H.match(ln): cH += 1; continue
            if pat_B.match(ln): cB += 1; continue
            if pat_I.match(ln): cI += 1; continue
            if pat_M.match(ln): cM += 1; continue
            if pat_E.match(ln): cE += 1; continue
            if m := pat_PK.match(ln):
                cPK += 1
                pk_bp_total += int(m.group(1))
                continue
            if m := pat_seg.match(ln):
                cSEG += 1
                continue

    return {
        "label": st_path.parent.name,     #  added folder labels to track the gene names - fixing missing labels
        "sample_id": name,
        "length": length,
        "n_stems": cS,
        "n_hairpins": cH,
        "n_internal": cI,
        "n_multiloops": cM,
        "n_bulges": cB,
        "n_exterior": cE,
        "n_segments": cSEG,
        "n_pseudoknots": cPK,
        "pk_total_bp": pk_bp_total,
        "st_path": str(st_path),
    }

def main(root):
    root = Path(root).expanduser().resolve()
    st_files = list(root.rglob("*.st"))
    if not st_files:
        print(f"No .st files found under: {root}")
        return

    out_csv = root / "bprna_shape_counts.csv"
    with out_csv.open("w", newline="") as fh: # features named
        cols = [
            "label", "sample_id", "length", "n_stems", "n_hairpins", 
            "n_internal", "n_multiloops", "n_bulges", "n_exterior",
            "n_segments", "n_pseudoknots", "pk_total_bp", "st_path"
        ]
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for f in st_files:
            try:
                w.writerow(count_shapes(f))
            except Exception as e:
                sys.stderr.write(f"Failed on {f}: {e}\n")

    print(f"Wrote: {out_csv}  (rows: {len(st_files)})")

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else ".")
