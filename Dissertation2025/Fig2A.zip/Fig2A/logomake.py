import os
from pathlib import Path
from collections import Counter
import pandas as pd
import matplotlib.pyplot as plt
from Bio import SeqIO
import logomaker

CENTER_POS_1IDX = 61
TOTAL_LEN = 121
FIXED_RADIUS = 15
ALPHABET = ["A","C","G","U"]

OUTDIR = Path("./pus7_outputs_pos_only2")
OUTDIR.mkdir(parents=True, exist_ok=True)

assays = {
    "hek_qb": {
        "pos": "/nobackup/tjxz93/pse_project/updated_ERNIE/ERNIE-RNA/data/ss_prediction/hek_qb.fasta",
        "title": " HEK293 PRAISE "
    },
    "hek_trub1_csv": {
        "pos": "/nobackup/tjxz93/pse_project/updated_ERNIE/ERNIE-RNA/data/ss_prediction/pus7_hek_csv_ENST_U_only.fasta",
        "title": "HEK293 CMC-based"
    },
    "hela_bidseq": {
        "pos": "/nobackup/tjxz93/pse_project/updated_ERNIE/ERNIE-RNA/data/ss_prediction/PUS7_positive_sequences_middleU.fa",
        "title": "HeLa BID-seq"
    },
    "hela_pseudoseq": {
        "pos": "/nobackup/tjxz93/pse_project/updated_ERNIE/ERNIE-RNA/data/ss_prediction/pus7_corrected_pse.fasta",
        "title": "HeLa Pseudo-seq"
    },
}

def rna_upper(s): 
    return s.strip().upper().replace("T","U")

def load_centered_pos_windows(fasta_path):
    wins, excl = [], Counter()
    for rec in SeqIO.parse(fasta_path, "fasta"):
        s = rna_upper(str(rec.seq))
        if len(s) != TOTAL_LEN:
            excl["wrong_length"] += 1; continue
        if s[CENTER_POS_1IDX-1] != "U":
            excl["center_not_U"] += 1; continue
        c0 = CENTER_POS_1IDX-1
        w = s[c0-FIXED_RADIUS : c0+FIXED_RADIUS+1]
        if len(w) != 2*FIXED_RADIUS+1:
            excl["window_oob"] += 1; continue
        wins.append(w)
    return wins, excl

def alignment_to_prob_matrix(seqs, alphabet=ALPHABET, pseudocount=1e-6):
    L = len(seqs[0])
    df = pd.DataFrame(0.0, index=range(L), columns=alphabet)
    for s in seqs:
        for i,b in enumerate(s):
            if b in alphabet:
                df.loc[i,b] += 1
    df += pseudocount
    return df.div(df.sum(axis=1), axis=0)

def plot_logo(prob_df, title, out_png):
    fig, ax = plt.subplots(figsize=(18,3))
    logomaker.Logo(prob_df, ax=ax)
    ax.axvline(x=FIXED_RADIUS - 0.5, linestyle="--", linewidth=1)
    ax.axhline(0, linewidth=0.8)
    ax.set_title(title, fontsize=16, fontweight="bold", pad=6)
    ax.set_xlabel("Position (center = 0)"); ax.set_ylabel("Probability")
    xticks = range(0, prob_df.shape[0], 2)
    ax.set_xticks(xticks); ax.set_xticklabels([str(i - FIXED_RADIUS) for i in xticks])
    ax.spines[['top','right']].set_visible(False)
    fig.tight_layout(); fig.savefig(out_png, dpi=300); plt.close(fig)

summary = []
for name, cfg in assays.items():
    print(f"\n=== {name} ===")
    outdir = OUTDIR / name
    outdir.mkdir(parents=True, exist_ok=True)

    pos_wins, excl = load_centered_pos_windows(cfg["pos"])
    n = len(pos_wins)
    print(f" kept: {n} | excluded: {dict(excl)}")

    if n == 0:
        summary.append({"assay": name, "kept": 0, **{f"excl_{k}": v for k,v in excl.items()}, "logo_png": ""})
        continue

    prob = alignment_to_prob_matrix(pos_wins)
    prob.to_csv(outdir / f"{name}_pos_prob.csv", index_label="position")


    plot_logo(prob, cfg["title"], outdir / f"{name}_pos_only_logo.png")

    summary.append({
        "assay": name,
        "kept": n,
        "excl_center_not_U": int(excl.get("center_not_U",0)),
        "excl_wrong_length": int(excl.get("wrong_length",0)),
        "excl_window_oob": int(excl.get("window_oob",0)),
        "logo_png": str(outdir / f"{name}_pos_only_logo.png"),
        "prob_csv": str(outdir / f"{name}_pos_prob.csv"),
    })

pd.DataFrame(summary).to_csv(OUTDIR / "summary_pos_only2.csv", index=False)
print("\nSummary saved to", OUTDIR / "summary_pos_only2.csv")